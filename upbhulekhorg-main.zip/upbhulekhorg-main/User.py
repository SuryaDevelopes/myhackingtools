class User:
    def __init__(self,khata,name,father):
        self.khatano=khata
        self.name=name
        self.father=father

    def getName(self):
        print(self.name)

    def getFather(self):
        print(self.father)

    def getKhataNo(self):
        print(self.khata)

