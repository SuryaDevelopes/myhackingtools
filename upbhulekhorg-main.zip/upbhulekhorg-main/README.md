
# Buy Me A Coffee



## UP Bhulekh
UPBhulekh is the tool that designed to help you find your
land in UttarPradesh. It helps to search your name in all villages
in the choosen District and Tehsil at once.

## USAGE

To use this, "sudo su" because it has module name keyboard that will 
check if a key pressed whenever pressed 'q' it will break.

```bash
  sudo su
  python3 setup.py
```


## 🚀 About Me
I'm just a College Student that has some hands on experience in some programming languages so I want to
use my skills to make the work easier.

